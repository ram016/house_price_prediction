from tkinter import *
from tkinter import ttk
import price_prediction as data
import tkinter.messagebox as Messagebox

def estimate():
    
    if(bhk_var.get()+2<bath_var.get()):
        Messagebox.showwarning('Error','Bathrooms cannot be 2 more than BHK')
    elif (not sqft.get().isdigit()):
        Messagebox.showwarning('Error', 'Area value invalid')
    elif(int(sqft.get())<300):
        Messagebox.showwarning('Error', 'Area cannot be less than 300')
    else:
        output=data.predict_price(l.get(),sqft.get(),bhk_var.get(),bath_var.get())
        Messagebox.showinfo('Price(in Lakhs)',round(output,2))

root = Tk()
root.title('House Price Prediction')
root.geometry('500x500')
root.configure(bg='blue')
root.resizable(True, True) 

l1 = Label(root, text="Area (in Square Feet)",font=('Arial',10,'bold'),bg='#ff0')
l1.place(x=20, y=20)

sqft=StringVar()

area = Entry(root, textvariable=sqft)
area.place(x=200, y=20)

bhk_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
bhk_var = IntVar()

l2 = Label(root, text="BHK(number of bedroom)",font=('Arial',10,'bold'),bg='#ff0')
l2.place(x=20, y=80)

bhk = ttk.Combobox(root, textvariable=bhk_var, values=bhk_list)
bhk.place(x=200, y=80)

bathrooms = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
bath_var = IntVar()

l3 = Label(root, text="Bathroom",font=('Arial',10,'bold'),bg='#ff0')
l3.place(x=20, y=140)

bath = ttk.Combobox(root, textvariable=bath_var, values=bathrooms)
bath.place(x=200, y=140)

locations=list(data.List)
l=StringVar()

l4 = Label(root, text="Location",font=('Arial',10,'bold'),bg='#ff0')
l4.place(x=20, y=200)

loc = ttk.Combobox(root, textvariable=l, values=locations)
loc.place(x=200, y=200)

btn = Button(root, text="Estimate price", bg='red' ,command=lambda: estimate())
btn.place(x=80, y=260)

root.mainloop()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




